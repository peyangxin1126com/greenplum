SHOW server_version;

SELECT * FROM aocs_users;

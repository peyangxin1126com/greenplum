\d+ p_diff_aligned_varlena

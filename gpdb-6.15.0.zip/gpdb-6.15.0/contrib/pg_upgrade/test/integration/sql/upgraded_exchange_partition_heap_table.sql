SHOW server_version;

SELECT * FROM table_part;

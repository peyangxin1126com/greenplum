void test_clusters_with_different_checksum_version_cannot_be_upgraded(void ** state);

SHOW server_version;

SELECT * FROM p_different_size_column;

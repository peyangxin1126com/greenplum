select * from users_with_check_constraints;

insert into users_with_check_constraints values (2, 'Jane');

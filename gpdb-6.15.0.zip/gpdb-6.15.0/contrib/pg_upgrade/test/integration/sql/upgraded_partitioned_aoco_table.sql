SHOW server_version;

SELECT * FROM p_aocs_table;

SELECT * FROM p_aocs_table_with_multiple_segfiles;

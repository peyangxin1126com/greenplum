#ifndef GPDB6_FILESPACES_TO_TABLESPACES_H
#define GPDB6_FILESPACES_TO_TABLESPACES_H

void
test_a_filespace_can_be_upgraded_into_new_tablespaces(void **state);

void
test_a_database_in_a_filespace_can_be_upgraded_into_new_tablespaces(void **state);

#endif //GPDB6_FILESPACES_TO_TABLESPACES_H

SHOW server_version;

SELECT * FROM users;

SHOW server_version;

SELECT * FROM p_ao_table;

SELECT * FROM p_ao_table_with_multiple_segfiles;

#define GPDB_FIVE_PORT 50000

void startGpdbFiveCluster(void);
void stopGpdbFiveCluster(void);

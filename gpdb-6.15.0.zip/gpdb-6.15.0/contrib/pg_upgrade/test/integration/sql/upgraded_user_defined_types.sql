SHOW server_version;

SELECT * FROM some_table ORDER BY id;

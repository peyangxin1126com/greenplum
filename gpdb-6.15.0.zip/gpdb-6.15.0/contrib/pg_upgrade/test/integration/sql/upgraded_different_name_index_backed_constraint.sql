SELECT * FROM table_with_unique_constraint;
SELECT * FROM table_with_primary_constraint;

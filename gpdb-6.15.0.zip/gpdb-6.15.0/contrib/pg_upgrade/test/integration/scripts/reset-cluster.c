#include <stdio.h>
#include <stdlib.h>

#include "utilities/test-helpers.h"

int
main(int argc, char *argv[])
{
	resetGpdbFiveDataDirectories();
	resetGpdbSixDataDirectories();
}

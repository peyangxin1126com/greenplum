#define GPDB_SIX_PORT 60000

void startGpdbSixCluster(void);
void stopGpdbSixCluster(void);

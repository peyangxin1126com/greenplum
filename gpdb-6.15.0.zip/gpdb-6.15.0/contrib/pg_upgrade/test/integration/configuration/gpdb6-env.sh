export MASTER_PORT=60000
export STANDBY_PORT=60001
export PORT_BASE=60000
export DATADIRS="$PWD/gpdb6-data"
export PGPORT=60000
export MASTER_DATA_DIRECTORY="$DATADIRS/qddir/demoDataDir-1"
export WITH_MIRRORS=false
export WITH_STANDBY=false

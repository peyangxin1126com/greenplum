#ifndef GREENPLUM_GREENPLUM_CLUSTER_INFO_H
#define GREENPLUM_GREENPLUM_CLUSTER_INFO_H
/*
 *	greenplum/greenplum_cluster_info.h
 *
 *	Portions Copyright (c) 2019-Present, Pivotal Software Inc
 *	contrib/pg_upgrade/greenplum/greenplum_cluster_info.h
 */

typedef struct GreenplumClusterInfoData GreenplumClusterInfo;

#endif

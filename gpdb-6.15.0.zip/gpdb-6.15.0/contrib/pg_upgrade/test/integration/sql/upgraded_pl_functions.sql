SHOW server_version;

SELECT someimmutablepythonfunction(0) as f;

SELECT someimmutablepsqlfunction(0) as f;

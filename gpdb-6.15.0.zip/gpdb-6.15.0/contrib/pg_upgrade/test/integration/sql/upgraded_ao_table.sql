SHOW server_version;

SELECT * FROM ao_users;

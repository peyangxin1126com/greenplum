SELECT * FROM mfk;
SELECT * FROM pt;
SELECT * FROM pt_another;
SELECT * FROM non_pt;

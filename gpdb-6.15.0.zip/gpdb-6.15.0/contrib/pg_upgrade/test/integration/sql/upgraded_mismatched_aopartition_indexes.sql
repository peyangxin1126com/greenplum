SELECT * FROM mismatched_partition_indexes;

-- there should be no entry in large object table
SELECT count(*) FROM pg_largeobject;
